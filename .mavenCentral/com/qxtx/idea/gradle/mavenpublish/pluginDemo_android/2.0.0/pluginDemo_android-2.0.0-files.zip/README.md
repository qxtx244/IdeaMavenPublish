libAndroid
==========
用于演示通过 Gradle 插件将 android library 发布到 maven 仓库的示例